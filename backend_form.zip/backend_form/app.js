const express = require('express');
const app = express();
const path = require("path")
const db = require('./model/User')


app.use(express.json());
app.use(express.urlencoded({ extended: true }))
app.use(express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs")

//=========Create========/>

app.get('/', (req, res) => {
    res.render("index")
})

//=========Update========/>

app.get('/edit/:userId', async (req, res) => {

    let users = await db.findOne({_id: req.params.userId});
    res.render("edit",{users})
})
app.post('/update/:userId', async (req, res) => {
    let {User ,email , image} =req.body

    let users = await db.findOneAndUpdate({_id: req.params.userId},{User,email,image},{new:true});
    res.redirect("/profile")
})

//=========Read========/>

app.get('/profile', async (req, res) => {

    let users = await db.find();
    res.render("profile", { users })
})

//=========Delete========/>
app.get('/delete/:id', async (req, res) => {

    let users = await db.findOneAndDelete({ _id: req.params.id });
    res.redirect("/profile")
})











app.post('/create', async (req, res) => {
    let { User, email, image } = req.body;

    const newUser = await db.create({
        User,
        email,
        image
    })
    res.redirect('/');
})

app.listen(2000, () => {
    console.log("the app is listing on 3000")
})