const mongoose = require('mongoose');


mongoose.connect('mongodb://localhost:27017/UserData_profile')
.then(()=>{
   console.log("connection done ")
}).catch((err)=>{
    console.err({error:"something went wrong"})
});

const userSchema = mongoose.Schema({
    User:String,
    email:String,
    image:String,
})

module.exports =mongoose.model('user',userSchema)